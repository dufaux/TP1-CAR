package exceptions;

public class FichierUserException extends RuntimeException {

	public FichierUserException(String string) {
		super(string);
	}

}
