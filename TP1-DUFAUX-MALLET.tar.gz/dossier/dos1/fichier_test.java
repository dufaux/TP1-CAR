Public class Test{

Non c'est une fausse classe!
}
